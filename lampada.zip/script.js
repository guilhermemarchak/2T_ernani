const btnAlternar = document.getElementById('btn-alternar');
const imgLampada = document.getElementById('lampada');
const baseUrl = "https://a8442d6c-3158-446d-80db-3b1cc87c3280-00-1h4n9xlo9qsq7.kirk.replit.dev/"

btnAlternar.addEventListener('click', function() {
  if (imgLampada.src == baseUrl + 'Lampada0.png') {
    imgLampada.src = "Lampada2.png"
  } else {
    imgLampada.src = "Lampada0.png"
  }
})
