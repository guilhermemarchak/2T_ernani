/**
  * FUNÇÕES: são blocos  de codígos que podem ser reaproveitados
  * funções que podem ou não ter nomes
  * podem ou não receber parâmetros
  */
// CRIAR OU DECLARAR FUNÇÕES
function dizOla(nome) {
  //codigo
  console.log('Olá ' + nome)
}
//INVOCAR / CHAMAR FUNÇÕES
dizOla('arthur')
dizOla('alemao')
dizOla('miguel')
dizOla('brenno')

//ADIÇÃO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}

somaDoisNumeros(27, 86)
somaDoisNumeros(96, 106)

//SUBTRAÇÃO
function subtraiDoisNumeros(x, y) {
  const subtracao = x - y
  console.log(subtracao)
}
subtraiDoisNumeros(72, 85)
subtraiDoisNumeros(95, 17)


//MULTIPLICAÇÃO
function multiplicaDoisNumeros(x, y) {
  const multiplacao = x * y
  console.log(multiplacao)
}
multiplicaDoisNumeros(34, 86)
multiplicaDoisNumeros(97, 54)


//DIVISÃO
function DivideDoisNumeros(x, y) { arthur
  const divisão = x / y
  console.log(divisão)
}
DivideDoisNumeros(67, 48)
DivideDoisNumeros(93, 24)

