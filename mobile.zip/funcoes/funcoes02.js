function dados  (nome, sobrenome){
if(typeof nome=== 'string' && typeof sobrenome === 'string'){
  alert("Ola" + " Guilherme " + "Marchak")
}else{alert('por favor insira um texto valido')}
}
dados('Guilherme', 'Marchak')