// FUNÇOES COM RETORNO 
// SAO FUÇÕES QUE RETORNAM UM VALOR
// PROCESSADO 
// PARA USO POSTERIOR
const nome = 'Guilherme'


function retornaDados() {
  //codigo com retorno
  return nome. toUpperCase()
  console.log('testando...')///INALCANÇÁVEL
  //A PARTIR DESSA LINHA NAO EXECUTA MAIS NADA...
  console.log(ola)
}                             
const dados = retornaDados()
console.log(dados)