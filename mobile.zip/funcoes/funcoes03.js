function dados(n) {
  if (n % 2 === 0) {
    alert('0 numero ' + n + ' é par ')
  } else { alert('0 numero ' + n + ' é impar ') }

}

// dados(4)
// dados(72)
// dados(53)

function parOuimpar (x){
  if (typeof x === 'number'){
    if (x % 2 === 0){
      alert('o numero ' + x + ' é par')
    }else{
      alert('o numero ' + x + ' é impar')
    }
}else{
    alert ('por favor insira um número válido')
}
}
  parOuimpar(123)
  parOuimpar(16)
 parOuimpar ("banana")